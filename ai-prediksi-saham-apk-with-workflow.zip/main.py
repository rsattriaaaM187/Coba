
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.spinner import Spinner
from kivy.core.window import Window
from kivy.core.clipboard import Clipboard
import yfinance as yf
import ta
import torch
import torch.nn as nn
import numpy as np
from sklearn.preprocessing import StandardScaler
import os

Window.size = (360, 720)

saham_list = ['BBRI.JK', 'BBCA.JK', 'TLKM.JK']

model_dir = './models_pth'
os.makedirs(model_dir, exist_ok=True)
device = torch.device("cpu")

class SahamNet(nn.Module):
    def __init__(self, input_dim):
        super(SahamNet, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.net(x)

def extract_features(df):
    df['rsi'] = ta.momentum.RSIIndicator(df['Close']).rsi()
    macd = ta.trend.MACD(df['Close'])
    df['macd'] = macd.macd()
    df['macd_signal'] = macd.macd_signal()
    df['ema10'] = ta.trend.EMAIndicator(df['Close'], window=10).ema_indicator()
    df['ema50'] = ta.trend.EMAIndicator(df['Close'], window=50).ema_indicator()
    df['ema_distance'] = (df['Close'] - df['ema10']) / df['ema10'] * 100
    bb = ta.volatility.BollingerBands(df['Close'])
    df['bb_upper'] = bb.bollinger_hband()
    df['bb_lower'] = bb.bollinger_lband()
    df['bb_breakout'] = ((df['Close'] > df['bb_upper']) | (df['Close'] < df['bb_lower'])).astype(int)
    df['atr'] = ta.volatility.AverageTrueRange(df['High'], df['Low'], df['Close']).average_true_range()
    df['roc'] = ta.momentum.ROCIndicator(df['Close']).roc()
    df['cci'] = ta.trend.CCIIndicator(df['High'], df['Low'], df['Close']).cci()
    df['volume_change'] = df['Volume'].pct_change()
    df['shooting_star'] = ((df['High'] - df['Low']) > 3*(df['Open'] - df['Close'])) &                           ((df['High'] - df['Close']) / (0.001 + df['High'] - df['Low']) > 0.6) &                           ((df['High'] - df['Open']) / (0.001 + df['High'] - df['Low']) > 0.6)
    df['shooting_star'] = df['shooting_star'].astype(int)
    df['ma_cross_bull'] = (df['ema10'] > df['ema50']).astype(int)
    df['ma_cross_bear'] = (df['ema10'] < df['ema50']).astype(int)
    df['macd_cross_bear'] = (df['macd'] < df['macd_signal']).astype(int)
    df['target'] = (df['Close'].shift(-3) > df['Close']).astype(int)
    df['future_change'] = ((df['Close'].shift(-3) - df['Close']) / df['Close']) * 100
    df.dropna(inplace=True)
    return df

def prediksi_saham(symbol):
    df = yf.download(symbol, period="1y")
    df = extract_features(df)
    fitur = [col for col in df.columns if col not in ['target', 'future_change']]
    X = df[fitur].values
    y = df['target'].values
    future_changes = df['future_change'].values
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    model_path = os.path.join(model_dir, f"model_{symbol.replace('.JK','')}.pth")
    input_dim = X.shape[1]
    model = SahamNet(input_dim).to(device)
    if os.path.exists(model_path):
        model.load_state_dict(torch.load(model_path, map_location=device))
    else:
        X_tensor = torch.tensor(X, dtype=torch.float32)
        y_tensor = torch.tensor(y.reshape(-1, 1), dtype=torch.float32)
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        criterion = nn.BCELoss()
        for epoch in range(100):
            model.train()
            output = model(X_tensor)
            loss = criterion(output, y_tensor)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        torch.save(model.state_dict(), model_path)
    model.eval()
    X_last = torch.tensor([X[-1]], dtype=torch.float32)
    with torch.no_grad():
        prob = model(X_last).item()
    future_change = future_changes[-1]
    signals = []
    if df['rsi'].iloc[-1] < 30:
        signals.append("RSI Oversold")
    if df['macd'].iloc[-1] > df['macd_signal'].iloc[-1]:
        signals.append("MACD Bullish")
    if df['shooting_star'].iloc[-1] == 1:
        signals.append("Shooting Star")
    if df['ma_cross_bull'].iloc[-1] == 1:
        signals.append("EMA Bullish")
    if df['bb_breakout'].iloc[-1] == 1:
        signals.append("Bollinger Breakout")
    if df['ma_cross_bear'].iloc[-1] == 1:
        signals.append("MA Cross Down")
    if df['macd_cross_bear'].iloc[-1] == 1:
        signals.append("MACD Death Cross")
    return ("BELI" if prob > 0.5 else "JUAL"), prob * 100 if prob > 0.5 else (1 - prob) * 100, future_change, signals

class SahamBox(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', padding=20, spacing=10)
        self.spinner = Spinner(text='Pilih Saham', values=saham_list)
        self.add_widget(self.spinner)
        self.hasil = Label(text='Hasil akan muncul di sini', halign='left', valign='middle')
        self.add_widget(self.hasil)
        self.prediksi_btn = Button(text='Prediksi Saham', size_hint=(1, 0.15))
        self.prediksi_btn.bind(on_press=self.prediksi)
        self.add_widget(self.prediksi_btn)
        self.clipboard_btn = Button(text='📋 Salin ke Clipboard', size_hint=(1, 0.15))
        self.clipboard_btn.bind(on_press=self.salin_clipboard)
        self.add_widget(self.clipboard_btn)
        self.hasil_teks = ''

    def prediksi(self, instance):
        teks_final = "📡 SINYAL SAHAM HARI INI\n"
        for kode in saham_list:
            arah, conf, change, sinyal = prediksi_saham(kode)
            simbol = "📈" if arah == "BELI" else "📉"
            teks_final += f"\n{simbol} {arah}: {kode}\n• Confidence: {conf:.1f}%\n• Estimasi {'Kenaikan' if arah == 'BELI' else 'Penurunan'}: {'+' if change >= 0 else ''}{change:.2f}%\n• Sinyal Teknis: {', '.join(sinyal) if sinyal else 'Tidak ada'}\n"
        self.hasil_teks = teks_final.strip()
        self.hasil.text = self.hasil_teks

    def salin_clipboard(self, instance):
        if not self.hasil_teks:
            self.hasil.text = '⚠️ Lakukan prediksi dulu sebelum menyalin.'
            return
        Clipboard.copy(self.hasil_teks.strip())
        self.hasil.text = '✅ Disalin ke clipboard.'

class SahamApp(App):
    def build(self):
        return SahamBox()

if __name__ == '__main__':
    SahamApp().run()
